package day6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayListSchool {
public static void main(String[] args) {
	ArrayList <School> al = new ArrayList <School>();
	al.add(new School (101,12,"Manoj"));
	al.add(new School (102,13,"Baskar"));
	al.add(new School (103,12,"Maran"));
	al.add(new School (104,14,"Hari"));
	
	Collections.sort(al);
	for(School sc : al) {
		System.out.println(sc.rollno+" "+sc.age+" "+sc.name);
	}
	
}
}


class School implements Comparable <School>{
	

int rollno,age;
String name;

public School(int rollno, int age, String name) {
	super();
	this.rollno = rollno;
	this.age = age;
	this.name = name;
}

public int  compareTo(School A) {
	if(age==A.age) {
		return 0;
	}
	else if(age>A.age) {
			return 1;
	}
	else 
	{
			return -1;
	}
		
}
}