package day6;

import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueExample {

	public static void main(String[] args) {
		
		PriorityQueue pqint1 = new PriorityQueue <Integer>();
		
		pqint1.add(12);
		pqint1.add(14);
		pqint1.add(16);
		
		//headElement
		System.out.println(pqint1.element());
		
		//headPeek
		System.out.println(pqint1.peek());
		
		//Iterating the element print one by one
		Iterator <Integer> pqit = pqint1.iterator();
		while(pqit.hasNext()) {
			System.out.println(pqit.next());
		}
		
		//remove the first element
		System.out.println(pqint1.remove());

		//print the first element
		System.out.println(pqint1.poll());
	}

}
