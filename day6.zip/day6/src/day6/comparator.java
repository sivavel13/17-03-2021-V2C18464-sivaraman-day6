package day6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Arrays;
import java.util.List;
import java.util.Comparator;

public class comparator {

	public static void main(String[] args) {
		
		ArrayList <Customer> al = new ArrayList <Customer>();
		al.add(new Customer ("Maran", 12, 2400));
		al.add(new Customer ("Hari", 8, 1600));
		al.add(new Customer ("Viml", 4, 1200));
		al.add(new Customer ("Karthik", 15, 54000));
		
		System.out.println("Sorting by name.....");
		Collections.sort(al,new NameComparator());
		Iterator it = al.iterator();
		while(it.hasNext()) {
			Customer cu = (Customer)it.next();
			System.out.println(cu.name+" "+cu.product+" "+cu.price);
		}
		
		System.out.println("Sorting by age.....");
		Collections.sort(al,new AgeComparator());
		Iterator it1 = al.iterator();
		while(it1.hasNext()) {
			Customer cu = (Customer)it1.next();
			System.out.println(cu.name+"  "+cu.product+"  "+cu.price);
	}
		

	}

}

class Customer{

	String name;
	int product,price;
	public Customer(String name, int product, int price) {
		super();
		this.name = name;
		this.product = product;
		this.price = price;
	}
}


class NameComparator implements Comparator <Object> {

	  public int  compare(Object o1,Object o2) {
				Customer s1 = (Customer) o1;
				Customer s2 = (Customer) o2;
				return s1.name.compareTo(s2.name);
	  }
	}

class AgeComparator implements Comparator <Object> {

	  public int  compare(Object o1,Object o2) {
				Customer s1 = (Customer) o1;
				Customer s2 = (Customer) o2;
				
				
				if(s1.product==s2.product) 
				{					
					return 0;
				}
				else if(s1.product>s2.product) {
					return 1;
				}
				else 
				{
					return -1;
				}
					
			}
}

